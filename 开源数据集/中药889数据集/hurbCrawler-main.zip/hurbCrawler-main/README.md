HurbCrawler
====

Libraries
-------
BeautifulSoup(bs4) urllib lxml requests

Disclaimer
-------
You are free to use this project for your school project, while its stability is not being guaranteed since my limited developing experience.

Usage
-------
Run hurbCrawler.py as main program

Data source and Data frame
-------
http://www.zhongyoo.com
Name,Medicine_Name,Alias,English_Name,Medicinal_Part,Source,Morphology,Distribution,Processing,Properties,Type,Effect,Usage,Constituent,Formula,Pharmacology,Taboo

Chinese Version
-------
中藥資料集爬取工具/中藥爬蟲/中药数据库爬虫
可從目標網站上爬取中藥資料
資料庫包括 中英文名稱，別稱，藥用部位，藥材來源，描述，加工製程，特點，特性，效果，用法用量，禁忌等
